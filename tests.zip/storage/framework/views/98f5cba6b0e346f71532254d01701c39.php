<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<center>

    <form>
        <?php echo csrf_field(); ?>
        <div class="col-md-7 col-lg-8">
            <h4 class="mb-3">Oda Ekle</h4>
            <form class="needs-validation" novalidate="">
              <div class="row g-6">

                <div class="col-sm-6">
                    <label for="lastName" class="form-label">Oda Türü</label>
                    <input name="tur" type="text" class="form-control" placeholder="" value="" required="">
                  </div>

                <div class="col-sm-6">
                    <label for="lastName" class="form-label">Kapasite</label>
                    <input name ="kapasite" type="number" class="form-control" placeholder="" value="" required="">
                  </div>


                <div class="col-sm-6">
                  <label for="lastName" class="form-label">1 Kisi Fiyatı</label>
                  <input name="tekfiyat" type="number" class="form-control" placeholder="" value="" required="">
                </div>

                <div class="col-sm-6">
                    <label for="lastName" class="form-label">Ek Kisi Fiyatı</label>
                    <input name="ekfiyat" type="number" class="form-control" placeholder="" value="" required="">
                  </div>
              </div>

<br>
        <button type="submit" class="btn btn-primary">Submit</button>
      </form>
<h2> Odalar </h2>

      <table class="table table-primary">

          <tr>
            <th scope="row">3</th>
            <td colspan="2" class="table-active">Larry the Bird</td>
            <td>@twitter</td>
          </tr>
        </tbody>
      </table>
</center>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\Users\mcozcan\Desktop\hotel-booking-system\hotel-booking-system\hotel-booking-system\resources\views/oda-ekle.blade.php ENDPATH**/ ?>