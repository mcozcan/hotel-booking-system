 <!-- Footer -->
 <div class="container">

    <footer class="d-flex flex-wrap justify-content-between align-items-center py-3 my-4 border-top">
        <center>
      <div class="col-md-12 d-flex align-items-center">
        <a href="/" class="mb-3 me-2 mb-md-0 text-body-secondary text-decoration-none ">
          <svg class="bi" width="30" height="24"><use xlink:href="#bootstrap"></use></svg>
        </a>
        <img src="<?php echo e(asset('front/img/logo.png')); ?>" width="200" height="70" alt="Web Sitesi Logosu" />
        <br>

        <span class="mb-12  text-body-secondary">Copyright © 2023 Uzunnu. Bütün Hakları Saklıdır.</span>
      </div>


    </center>
    </footer>

      <!-- Footer -->
  </div>
</html>
<?php /**PATH C:\Users\mcozcan\Desktop\hotel-booking-system\hotel-booking-system\hotel-booking-system\resources\views/layouts/footer.blade.php ENDPATH**/ ?>