<?php if(Auth::check()): ?>


<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<center>

  <h2> Rezervasyonlarım </h2>

<?php
    $id = Auth::id();
    $rezervasyonlarim = DB::table('rezervasyons')->where('musteri_id','=',$id)->get();
    $rzvoda = DB::table('rezervasyons')->where('musteri_id','=',$id)->first();
    $odaturu = DB::table('rooms')->where('id','=',$rzvoda->oda_id)->first();
?>
  <table style="width:80%" class="table">
    <thead>
      <tr>
        <th scope="col">Oda Numarası</th>
        <th scope="col">Oda Türü</th>
        <th scope="col">Kişi Sayısı</th>
        <th scope="col">Giriş Tarihi</th>
        <th scope="col">Çıkış Tarihi</th>
        <th scope="col">Fiyat</th>
      </tr>
    </thead>
    <tbody class="table-group-divider">



 <?php $__currentLoopData = $rezervasyonlarim; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rzv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <th scope="row"><?php echo e($rzv ->id); ?></th>
        <td><?php echo e($odaturu ->oda_turu); ?></td>
        <td><?php echo e($rzv ->kisi_sayisi); ?></td>
        <td><?php echo e($rzv ->total_fiyat); ?> TL</td>
        <td><?php echo e($rzv->giris); ?> </td>
        <td><?php echo e($rzv->cikis); ?> </td>



      </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>
  </table>


</center>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
<meta http-equiv="refresh" content="0;URL=/">
<?php endif; ?>
<?php /**PATH C:\Users\mcozcan\Desktop\hotel-booking-system\hotel-booking-system\hotel-booking-system\resources\views/rezervasyonlarim.blade.php ENDPATH**/ ?>