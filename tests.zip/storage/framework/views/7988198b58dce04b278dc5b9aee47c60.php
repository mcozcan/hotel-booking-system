<?php if(Auth::id() != 1): ?>
<meta http-equiv="refresh" content="0;URL=/">

<?php else: ?>

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<center>

    <form method="post" action="<?php echo e(route('odaekle')); ?>" accept-charset="UTF-8">
        <?php echo csrf_field(); ?>
        <div class="col-md-7 col-lg-8">
            <h4 class="mb-3">Oda Ekle</h4>
            <form class="needs-validation" novalidate="">
              <div class="row g-6">

                <div class="col-sm-6">
                    <label for="lastName" class="form-label">Oda Türü</label>
                    <input name="odaturu" type="text" class="form-control" placeholder="" value="" required="">
                  </div>

                <div class="col-sm-6">
                    <label for="lastName" class="form-label">Kapasite</label>
                    <input name ="kapasite" type="number" class="form-control" placeholder="" value="" required="">
                  </div>


                <div class="col-sm-6">
                  <label for="lastName" class="form-label">1 Kisi Fiyatı</label>
                  <input name="tekfiyat" type="number" class="form-control" placeholder="" value="" required="">
                </div>

                <div class="col-sm-6">
                    <label for="lastName" class="form-label">Ek Kisi Fiyatı</label>
                    <input name="ekfiyat" type="number" class="form-control" placeholder="" value="" required="">
                  </div>
              </div>

<br>
        <button type="submit" class="btn btn-primary">Kaydet</button>
      </form>
      <br>
      <br>
      <br>
<h2> Odalar </h2>


  <table class="table">
    <thead>
      <tr>
        <th scope="col">Oda Numarası</th>
        <th scope="col">Oda Türü</th>
        <th scope="col">Kapasite</th>
        <th scope="col">Tek Fiyat</th>
        <th scope="col">Ek Fiyat</th>
        <th scope="col">Düzenle</th>
      </tr>
    </thead>
    <tbody class="table-group-divider">
 <?php $__currentLoopData = $odalar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $oda): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <th scope="row"><?php echo e($oda->id); ?></th>
        <td><?php echo e($oda->oda_turu); ?></td>
        <td><?php echo e($oda->kapasite); ?></td>
        <td><?php echo e($oda->tek_kisi_fiyati); ?> TL</td>
        <td><?php echo e($oda->ek_kisi_fiyati); ?> TL</td>
        <td> <a href="<?php echo e(route('oda-duzenle', $oda->id)); ?>"><span>Düzenle</span></a> </td>


      </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>
  </table>
</center>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<?php /**PATH C:\Users\mcozcan\Desktop\hotel-booking-system\hotel-booking-system\hotel-booking-system\resources\views/odalar.blade.php ENDPATH**/ ?>