<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<center>

    <h1>Admin Panel</h1>
    <div>
        <label for="giris">Giriş Tarihi:</label>
        <input type="date" id="giris" name="giris">

        <label for="cikis">Çıkış Tarihi:</label>
        <input type="date" id="cikis" name="cikis">

        <label for="musteri_id">Müşteri ID:</label>
        <input type="text" id="musteri_id" name="musteri_id">

        <button id="showDetails">Detayları Göster</button>
    </div>

    <div id="detailsContainer" style="display: none;">
        <p id="girisDetails"></p>
        <p id="cikisDetails"></p>
        <p id="musteriIdDetails"></p>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function () {
            $("#showDetails").click(function () {
                var giris = $("#giris").val();
                var cikis = $("#cikis").val();
                var musteriId = $("#musteri_id").val();

                $("#girisDetails").text("Giriş Tarihi: " + giris);
                $("#cikisDetails").text("Çıkış Tarihi: " + cikis);
                $("#musteriIdDetails").text("Müşteri ID: " + musteriId);

                $("#detailsContainer").show();
            });
        });
    </script>

</center>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\Users\mcozcan\Desktop\hotel-booking-system\hotel-booking-system\hotel-booking-system\resources\views/anliksorgular.blade.php ENDPATH**/ ?>