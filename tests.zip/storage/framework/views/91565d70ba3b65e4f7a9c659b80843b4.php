<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <div class="container">
        <header class="d-flex flex-wrap align-items-center justify-content-center justify-content-md-between py-3 mb-4 border-bottom">
          <div class="col-md-3 mb-2 mb-md-0">
            <a href="/" class="d-inline-flex link-body-emphasis text-decoration-none">
              <svg class="bi" width="40" height="32" role="img" aria-label="Bootstrap"><use xlink:href="#bootstrap"></use></svg>
            </a>
            <img src="<?php echo e(asset('front/img/logo.png')); ?>" width="200" height="70" alt="Web Sitesi Logosu" />
          </div>

          <ul class="nav col-12 col-md-auto mb-2 justify-content-center mb-md-0">
            <li><a href="/" class="nav-link px-2 link-secondary">Ana Sayfa</a></li>
            <li><a href="/hakkimizda" class="nav-link px-2">Hakkımızda</a></li>
            <?php if(Auth::check()): ?>

            <?php else: ?>
            <li><a href="/login" class="nav-link px-2">Rezervasyon Yap</a></li>
            <?php endif; ?>

            <?php if(Auth::check()): ?>
            <?php if(Auth::user()->id == 1): ?>
                <li><a href="/rezervasyonlar" class="nav-link px-2">Rezervasyonları Gör</a></li>
                <li><a href="/odalar" class="nav-link px-2">Odalar</a></li>
                <li><a href="/rezervasyon-sorgula" class="nav-link px-2">Kod Sorgula</a></li>
                <li><a href="/anliksorgu" class="nav-link px-2">Son Sorgu</a></li> <!-- Müşteri baktığı anda buraya düşüyor-->

            <?php else: ?>
            <li><a href="/rezervasyonlarim" class="nav-link px-2">Rezervasyonlarım</a></li>
            <li><a href="/rezervasyon-yap" class="nav-link px-2">Rezervasyon Yap</a></li>
            <?php endif; ?>
            <?php endif; ?>


          </ul>
<?php if(auth()->guard()->check()): ?>

<?php endif; ?>
          <div class="col-md-3 text-end">

            <?php if(Auth::check()): ?>
            <?php
            $username =  Auth::user()->name;
          ?>

                <h4>Hoşgeldin <?php echo e($username); ?> </h4>
                <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">Çıkış Yap</a>

<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
    <?php echo csrf_field(); ?>
</form>
            <?php else: ?>
            <a href="/login" <button type="button" class="btn btn-outline-primary me-2">Giriş Yap</button></a>
            <a href="/register" <button type="button" class="btn btn-primary">Kayıt Ol</button></a>
             <?php endif; ?>

          </div>
        </header>
      </div>

    <link href="<?php echo e(asset('front/css/bootstrap.min.css')); ?>" rel="stylesheet">
  </head>
<?php /**PATH C:\Users\mcozcan\Desktop\hotel-booking-system\hotel-booking-system\hotel-booking-system\resources\views/layouts/header.blade.php ENDPATH**/ ?>