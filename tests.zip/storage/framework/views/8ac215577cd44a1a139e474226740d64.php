<?php if(Auth::id() != 1): ?>
<meta http-equiv="refresh" content="0;URL=/">

<?php else: ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php
    $jsonPath = public_path('reservations.json');
    $jsonData = file_exists($jsonPath) ? json_decode(file_get_contents($jsonPath)) : null;
?>

<?php if($jsonData): ?>
<center>
    <!-- 5 numaralı madde için yazıldı -->
    <p>Giriş Tarihi: <?php echo e($jsonData->giris); ?></p>
    <p>Çıkış Tarihi: <?php echo e($jsonData->cikis); ?></p>
    <p>Müşteri ID: <?php echo e($jsonData->musteriid); ?></p>
</center>
<?php endif; ?>


<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php endif; ?>

<?php /**PATH C:\Users\mcozcan\Desktop\hotel-booking-system\hotel-booking-system\hotel-booking-system\resources\views/anliksorgu.blade.php ENDPATH**/ ?>